import { css } from '@emotion/react'
import { UserTable } from './components/user-table'

function App() {
  return (
    <div css={styles.layout}>
      <div css={styles.userTable}>
        <UserTable />
      </div>
    </div>
  )
}

const styles = {
  layout: css`
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 2rem;
  `,
  userTable: css`
    margin: 1rem;
  `,
}

export default App
