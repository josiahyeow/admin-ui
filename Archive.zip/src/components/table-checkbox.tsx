import { css } from '@emotion/react'
import { HTMLProps, useEffect, useRef } from 'react'

export function TableCheckbox({
  indeterminate,
  ...rest
}: {
  indeterminate?: boolean
} & HTMLProps<HTMLInputElement>) {
  const ref = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!ref.current) return
    if (typeof indeterminate === 'boolean') {
      ref.current.indeterminate = !rest.checked && indeterminate
    }
  }, [ref, indeterminate])

  return <input type="checkbox" ref={ref} css={styles.checkbox} {...rest} />
}

const styles = {
  checkbox: css``,
}
