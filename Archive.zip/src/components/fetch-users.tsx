import { useEffect, useState } from 'react'

const USERS_ENDPOINT =
  'https://geektrust.s3-ap-southeast-1.amazonaws.com/adminui-problem/members.json'

export type User = {
  id: string
  name: string
  email: string
  role: string
}

export function useUsers() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(false)

  const fetchUsers = async () => {
    setLoading(true)
    const response = await fetch(USERS_ENDPOINT)
    const data = await response.json()
    setUsers(data)
    setLoading(false)
  }

  useEffect(() => {
    fetchUsers()
  }, [])

  const editUser = (id: string, data: Partial<User>) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === id) {
          return { ...u, ...data }
        }
        return u
      })
    )
  }

  const deleteUser = (id: string) => {
    setUsers((prev) => prev.filter((user) => user.id !== id))
  }

  const deleteUsers = (ids: string[]) => {
    setUsers((prev) => prev.filter((user) => !ids.includes(user.id)))
  }

  return { users, editUser, deleteUser, deleteUsers, loading }
}
