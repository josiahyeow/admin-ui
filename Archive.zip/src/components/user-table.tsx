import { css } from '@emotion/react'
import { rankItem } from '@tanstack/match-sorter-utils'
import {
  ColumnDef,
  FilterFn,
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  useReactTable,
} from '@tanstack/react-table'
import { useMemo, useState } from 'react'
import { color } from '../styles/colors'
import { DeleteSelectedButton } from './delete-selected-button'
import { User, useUsers } from './fetch-users'
import { TableActions } from './table-actions'
import { TableCheckbox } from './table-checkbox'
import { TableEditableColumn } from './table-editable-column'
import { TablePageControls } from './table-page-controls'
import { TableSearchBar } from './table-searchbar'
import { UserRoleTag } from './user-role-tag'

export function UserTable() {
  const { users, deleteUser, deleteUsers, editUser, loading } = useUsers()

  const [currentEditableRowId, setCurrentEditableRowId] = useState<
    string | null
  >(null)
  const columnHelper = createColumnHelper<User>()

  const defaultColumn: Partial<ColumnDef<User>> = {
    cell: (props) => (
      <TableEditableColumn
        {...props}
        isEditing={currentEditableRowId === props.row.id}
        editUser={editUser}
      />
    ),
  }

  const columns = useMemo(
    () => [
      columnHelper.display({
        id: 'select-col',
        header: ({ table }) => (
          <TableCheckbox
            checked={table.getIsAllPageRowsSelected()}
            indeterminate={table.getIsSomeRowsSelected()}
            onChange={table.getToggleAllPageRowsSelectedHandler()}
          />
        ),
        cell: ({ row }) => (
          <TableCheckbox
            checked={row.getIsSelected()}
            disabled={!row.getCanSelect()}
            onChange={row.getToggleSelectedHandler()}
          />
        ),
      }),
      {
        accessorKey: 'name',
        header: 'Name',
        cell: currentEditableRowId
          ? defaultColumn.cell
          : (props) => (
              <span css={styles.name}>{props.row.getValue('name')}</span>
            ),
      },
      {
        accessorKey: 'email',
        header: 'Email',
        cell: currentEditableRowId
          ? defaultColumn.cell
          : (props) => (
              <span css={styles.email}>{props.row.getValue('email')}</span>
            ),
      },
      {
        accessorKey: 'role',
        header: 'Role',
        cell: currentEditableRowId
          ? defaultColumn.cell
          : (props) => (
              <div css={{ display: 'flex' }}>
                <UserRoleTag role={props.row.getValue('role')} />
              </div>
            ),
      },
      columnHelper.display({
        id: 'actions',
        cell: (props) => {
          const isEditing = currentEditableRowId === props.row.id
          return (
            <TableActions
              isEditing={isEditing}
              onEdit={() => {
                setCurrentEditableRowId(props.row.id)
              }}
              onSave={() => {
                setCurrentEditableRowId(null)
              }}
              onDelete={() => deleteUser(props.row.id)}
            />
          )
        },
        header: () => <div css={styles.actions}>Actions</div>,
      }),
    ],
    [columnHelper, currentEditableRowId, defaultColumn.cell, deleteUser]
  )

  const [rowSelection, setRowSelection] = useState({})
  const [globalFilter, setGlobalFilter] = useState('')

  const table = useReactTable({
    data: users,
    defaultColumn,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onRowSelectionChange: setRowSelection,
    globalFilterFn: fuzzyFilter,
    onGlobalFilterChange: setGlobalFilter,
    getRowId: (row) => row.id,
    state: {
      rowSelection,
      globalFilter,
    },
    meta: {
      editUser,
    },
  })

  if (loading) {
    return <div>Loading...</div>
  }

  return (
    <div css={styles.layout}>
      <div css={styles.controls}>
        <div css={styles.control}>
          <TableSearchBar table={table} />
        </div>
        <div css={styles.control}>
          <DeleteSelectedButton table={table} deleteUsers={deleteUsers} />
        </div>
      </div>

      <table css={styles.table}>
        <thead css={styles.header}>
          {table.getHeaderGroups().map((headerGroup) => (
            <tr key={headerGroup.id}>
              {headerGroup.headers.map((header) => (
                <th key={header.id} css={[styles.cell, styles.headerRow]}>
                  {header.isPlaceholder
                    ? null
                    : flexRender(
                        header.column.columnDef.header,
                        header.getContext()
                      )}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody>
          {table.getRowModel().rows.map((row) => (
            <tr key={row.id} css={styles.row(row.getIsSelected())}>
              {row.getVisibleCells().map((cell) => (
                <td key={cell.id} css={[styles.cell]}>
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
        <tfoot>
          {table.getFooterGroups().map((footerGroup) => (
            <tr key={footerGroup.id}>
              {footerGroup.headers.map((header) => (
                <th key={header.id}>
                  {header.isPlaceholder
                    ? null
                    : flexRender(
                        header.column.columnDef.footer,
                        header.getContext()
                      )}
                </th>
              ))}
            </tr>
          ))}
        </tfoot>
      </table>

      <TablePageControls table={table} />
    </div>
  )
}

const fuzzyFilter: FilterFn<User> = (row, columnId, value, addMeta) => {
  const itemRank = rankItem(row.getValue(columnId), value, { threshold: 4 })
  addMeta({
    itemRank,
  })
  return itemRank.passed
}

const styles = {
  layout: css`
    display: flex;
    flex-direction: column;
    align-items: center;
    min-width: 90vw;
    max-width: 90vw;
  `,
  search: css`
    align-self: flex-start;
  `,
  table: css`
    background-color: ${color.white};
    width: 100%;
    margin: 1rem;
    border: 1px solid ${color.grey20};
    border-spacing: 0px;
    overflow: hidden;
    border-collapse: collapse;
  `,
  header: css`
    color: ${color.grey70};
    background-color: ${color.grey05};
  `,
  headerRow: css`
    text-align: left;
    border-bottom: 1px solid ${color.grey20};
  `,
  name: css`
    font-weight: 500;
  `,
  email: css``,
  role: css`
    display: flex;
  `,
  actions: css`
    text-align: center;
  `,
  cell: css`
    color: ${color.grey95};
    padding: 0.6rem;
    font-size: 0.8rem;
  `,
  row: (isSelected: boolean) => css`
    ${isSelected && `background-color: ${color.grey05}`};
    border-bottom: 1px solid ${color.grey20};

    &:hover {
      background-color: ${color.grey05};
    }

    &:last-child {
      border: none;
    }
  `,
  controls: css`
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
  `,
  control: css``,
}
